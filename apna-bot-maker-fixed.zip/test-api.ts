import axios from 'axios';

async function test() {
  try {
    const res = await axios.get('http://localhost:3000/api/bots/auto-deploy?key=bad088b9-daf&token=12345:invalid');
    console.log(res.data);
  } catch (err: any) {
    console.error(err.response?.data || err.message);
  }
}
test();
