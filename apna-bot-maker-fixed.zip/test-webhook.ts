import { Telegraf } from 'telegraf';

async function test() {
  const bot = new Telegraf('123:test');
  console.log("has handleUpdate:", typeof bot.handleUpdate);
}

test();
