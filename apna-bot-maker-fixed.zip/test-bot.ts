import { Telegraf } from 'telegraf';
import vm from 'vm';

async function test() {
  const bot = new Telegraf('insert invalid token here');
  bot.catch(e => console.error('Caught:', e));
  
  const code = `
    bot.start((ctx) => ctx.reply('Started!'));
    bot.on('text', (ctx) => ctx.reply('Text!'));
  `;
  
  const sandbox = { bot, console };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox);
  
  try {
    await bot.telegram.getMe();
    bot.launch().catch(e => console.log('Launch catch', e));
  } catch (err: any) {
    console.log('Setup failed:', err.message);
  }
}

test();
