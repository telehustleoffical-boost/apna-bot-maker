import { Telegraf } from 'telegraf';
import vm from 'vm';
import fs from 'fs';
import path from 'path';

// ── Persistence ──────────────────────────────────────────────────────────────
const BOTS_FILE = path.join(process.cwd(), 'active-bots.json');

interface BotRecord {
  token: string;
  name: string;
  username: string;
  startedAt: string;
}

interface BotInstance {
  token: string;
  name: string;
  bot: Telegraf;
  info: any;
  startedAt: Date;
  code?: string;
}

const activeBots = new Map<string, BotInstance>();

function persistBots() {
  try {
    const records: BotRecord[] = Array.from(activeBots.values()).map(b => ({
      token: b.token,
      name: b.name,
      username: b.info.username,
      startedAt: b.startedAt.toISOString(),
    }));
    fs.writeFileSync(BOTS_FILE, JSON.stringify(records, null, 2));
  } catch (e) {
    console.error('[BotManager] Persist error:', e);
  }
}

// ── Restore bots on server startup ───────────────────────────────────────────
export async function restoreBots(globalCode: string, appUrl?: string) {
  if (!fs.existsSync(BOTS_FILE)) return;
  try {
    const records: BotRecord[] = JSON.parse(fs.readFileSync(BOTS_FILE, 'utf-8'));
    console.log(`[BotManager] Restoring ${records.length} bot(s)...`);
    for (const rec of records) {
      try {
        await addBot(rec.token, rec.name, globalCode, appUrl, true);
        console.log(`[BotManager] ✅ Restored @${rec.username}`);
      } catch (e: any) {
        console.error(`[BotManager] ❌ Failed to restore ${rec.username}: ${e.message}`);
      }
    }
  } catch (e) {
    console.error('[BotManager] Error reading bots file:', e);
  }
}

// ── Add & launch a bot ────────────────────────────────────────────────────────
export async function addBot(
  token: string,
  name?: string,
  code?: string,
  requestAppUrl?: string,
  isRestore = false
) {
  if (activeBots.has(token)) {
    if (isRestore) return; // skip silently on restore
    throw new Error('Bot with this token is already running.');
  }

  const bot = new Telegraf(token);

  // Apply bot logic (custom code or default)
  if (code && code.trim() !== '') {
    const sandbox = {
      bot, console, setTimeout, clearTimeout,
      setInterval, clearInterval, Buffer, Math, Date, JSON, fetch,
      process: { env: {} },
    };
    vm.createContext(sandbox);
    try {
      vm.runInContext(code, sandbox, { timeout: 2000 });
    } catch (err: any) {
      throw new Error(`Code compile error: ${err.message}`);
    }
  } else {
    bot.start((ctx) => ctx.reply('Hello! I am online and powered by BotNest! 🚀'));
    bot.on('text', (ctx) => ctx.reply(`Echo: ${ctx.message.text}`));
  }

  bot.catch((err: any, ctx: any) => {
    console.error(`[Bot Error] ${ctx?.updateType}:`, err?.message);
  });

  // Validate token with Telegram
  let me: any;
  try {
    me = await bot.telegram.getMe();
  } catch (e: any) {
    throw new Error(`Invalid token: ${e.message}`);
  }

  // ── Decide: Webhook (cloud) or Polling (local) ───────────────────────────
  const baseUrl = requestAppUrl || process.env.APP_URL || '';

  // Force HTTPS — Telegram rejects HTTP webhooks
  const safeUrl = baseUrl.replace(/^http:\/\//, 'https://').replace(/\/$/, '');
  const isCloud = safeUrl.startsWith('https://') && !safeUrl.includes('localhost');

  // Always delete old webhook first to avoid conflicts
  await bot.telegram.deleteWebhook({ drop_pending_updates: true });

  if (isCloud) {
    const webhookUrl = `${safeUrl}/api/bots/webhook/${token}`;
    console.log(`[BotManager] Setting webhook → ${webhookUrl}`);
    try {
      await bot.telegram.setWebhook(webhookUrl, { drop_pending_updates: true });
      console.log(`[BotManager] ✅ Webhook active for @${me.username}`);
    } catch (e: any) {
      // Webhook failed → fallback to polling
      console.warn(`[BotManager] Webhook failed, using polling: ${e.message}`);
      bot.launch().catch(err => console.error(`[Polling] @${me.username}:`, err.message));
    }
  } else {
    console.log(`[BotManager] Polling mode for @${me.username}`);
    bot.launch().catch(err => console.error(`[Polling] @${me.username}:`, err.message));
  }

  const instance: BotInstance = {
    token,
    name: name || me.first_name,
    bot,
    info: me,
    startedAt: new Date(),
    code,
  };

  activeBots.set(token, instance);
  persistBots(); // Save to disk immediately

  return {
    username: me.username,
    name: instance.name,
    startedAt: instance.startedAt,
  };
}

// ── Stop & remove a bot ───────────────────────────────────────────────────────
export function removeBot(token: string): boolean {
  const instance = activeBots.get(token);
  if (instance) {
    try {
      instance.bot.stop('Stopped');
      instance.bot.telegram.deleteWebhook({ drop_pending_updates: true }).catch(() => {});
    } catch (_) {}
    activeBots.delete(token);
    persistBots();
    return true;
  }
  return false;
}

export function getBotInstance(token: string): BotInstance | undefined {
  return activeBots.get(token);
}

export function getActiveBots() {
  return Array.from(activeBots.values()).map(b => ({
    token: b.token,
    maskedToken: b.token.substring(0, 8) + '...',
    username: b.info.username,
    name: b.name,
    startedAt: b.startedAt,
  }));
}

// Graceful shutdown
process.once('SIGINT', () => activeBots.forEach(i => i.bot.stop('SIGINT')));
process.once('SIGTERM', () => activeBots.forEach(i => i.bot.stop('SIGTERM')));
